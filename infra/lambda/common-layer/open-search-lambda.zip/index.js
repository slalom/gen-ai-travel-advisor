const { Client } = require('@opensearch-project/opensearch');
const { AwsSigv4Signer } = require('@opensearch-project/opensearch/aws-v3');
const { defaultProvider } = require('@aws-sdk/credential-provider-node')

const AWS = require('aws-sdk');

exports.handler = async (event) => {
    const { IndexName } = event.ResourceProperties; // Get the index name from the custom resource properties
    const region = process.env.AWS_REGION;
    const endpoint = process.env.OPENSEARCH_ENDPOINT; // Set the OpenSearch endpoint as an environment variable

    const client = new Client({
        ...AwsSigv4Signer({
            region,
            service: 'aoss',
            getCredentials: () => {
                const credentialProvider = defaultProvider();
                return credentialProvider();
            }
        }),
        node: endpoint,
    });

    try {
        if (event.RequestType === 'Create') {
            console.log(`Creating index: ${IndexName}`);
            await client.indices.create({
                index: IndexName,
                body: {
                    settings: { number_of_shards: 1 },
                    mappings: {
                        properties: {
                            title: { type: 'text' },
                            description: { type: 'text' },
                        },
                    },
                },
            });
        } else if (event.RequestType === 'Delete') {
            console.log(`Deleting index: ${IndexName}`);
            await client.indices.delete({ index: IndexName });
        }

        return {
            PhysicalResourceId: IndexName,
        };
    } catch (error) {
        console.error('Error creating or deleting index:', error);
        throw new Error(`Failed to create or delete OpenSearch index: ${error.message}`);
    }
};
